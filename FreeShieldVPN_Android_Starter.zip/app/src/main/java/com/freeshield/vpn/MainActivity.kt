package com.freeshield.vpn

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var backend: Backend
    private lateinit var vpnTunnel: AppTunnel
    private lateinit var status: TextView
    private lateinit var serverSpinner: Spinner
    private lateinit var connectButton: Button
    private var pendingConnect = false

    private data class Server(val id: String, val title: String, val tier: String)
    private val servers = listOf(
        Server("pakistan", "Pakistan", "FREE"),
        Server("usa", "United States", "FREE"),
        Server("uk", "United Kingdom", "PREMIUM"),
        Server("germany", "Germany", "PREMIUM"),
        Server("japan", "Japan", "PREMIUM")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(this)
        vpnTunnel = AppTunnel()
        buildScreen()
        refreshState()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(8, 11, 10))
        }

        val title = TextView(this).apply {
            text = "FreeShield VPN"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "PRIVATE • SECURE • SIMPLE"
            textSize = 11f
            setTextColor(Color.rgb(25, 214, 107))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        page.addView(subtitle, matchWrap())

        val serverLabel = TextView(this).apply {
            text = "SELECT SERVER"
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        page.addView(serverLabel, matchWrap())

        serverSpinner = Spinner(this)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            servers.map { "${it.title}  •  ${it.tier}" }
        )
        serverSpinner.adapter = adapter
        page.addView(serverSpinner, matchWrap())

        status = TextView(this).apply {
            text = "DISCONNECTED"
            textSize = 17f
            setTextColor(Color.rgb(25, 214, 107))
            gravity = Gravity.CENTER
            setPadding(0, 34, 0, 22)
        }
        page.addView(status, matchWrap())

        connectButton = Button(this).apply {
            text = "CONNECT"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(25, 214, 107))
            setOnClickListener { onConnectPressed() }
        }
        page.addView(connectButton, LinearLayout.LayoutParams(260, 58).apply {
            gravity = Gravity.CENTER
        })

        val note = TextView(this).apply {
            text = "Real VPN service requires a valid WireGuard server configuration. No fake servers are included."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 0)
        }
        page.addView(note, matchWrap())

        val footer = TextView(this).apply {
            text = "FreeShield • Your connection, your choice"
            textSize = 11f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 26, 0, 0)
        }
        page.addView(footer, matchWrap())

        setContentView(page)
    }

    private fun onConnectPressed() {
        val selected = servers[serverSpinner.selectedItemPosition]
        val configText = try {
            assets.open("wireguard/${selected.id}.conf").bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            status.text = "SERVER NOT CONFIGURED"
            Toast.makeText(
                this,
                "Add a real ${selected.title} WireGuard config to app/src/main/assets/wireguard/${selected.id}.conf",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        try {
            val config = Config.parse(ByteArrayInputStream(configText.toByteArray()))
            val prepareIntent = GoBackend.VpnService.prepare(this)
            if (prepareIntent != null) {
                pendingConnect = true
                @Suppress("DEPRECATION")
                startActivityForResult(prepareIntent, VPN_PERMISSION_REQUEST)
            } else {
                startTunnel(config)
            }
        } catch (e: Exception) {
            status.text = "CONFIGURATION ERROR"
            Toast.makeText(this, e.message ?: "Invalid WireGuard config", Toast.LENGTH_LONG).show()
        }
    }

    private fun startTunnel(config: Config) {
        try {
            backend.setState(vpnTunnel, Tunnel.State.UP, config)
            status.text = "CONNECTED • ${servers[serverSpinner.selectedItemPosition].title}"
            connectButton.text = "DISCONNECT"
            connectButton.setOnClickListener { disconnect() }
        } catch (e: Exception) {
            status.text = "CONNECTION FAILED"
            Toast.makeText(this, e.message ?: "Could not connect", Toast.LENGTH_LONG).show()
        }
    }

    private fun disconnect() {
        try {
            backend.setState(vpnTunnel, Tunnel.State.DOWN, null)
        } catch (_: Exception) { }
        status.text = "DISCONNECTED"
        connectButton.text = "CONNECT"
        connectButton.setOnClickListener { onConnectPressed() }
    }

    private fun refreshState() {
        try {
            if (backend.getState(vpnTunnel) == Tunnel.State.UP) {
                status.text = "CONNECTED"
                connectButton.text = "DISCONNECT"
                connectButton.setOnClickListener { disconnect() }
            }
        } catch (_: Exception) { }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_PERMISSION_REQUEST && pendingConnect) {
            pendingConnect = false
            if (resultCode == Activity.RESULT_OK) onConnectPressed()
            else status.text = "VPN PERMISSION DENIED"
        }
    }

    private inner class AppTunnel : Tunnel {
        override fun getName(): String = "FreeShield"
        override fun onStateChange(newState: Tunnel.State) { }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    companion object {
        private const val VPN_PERMISSION_REQUEST = 7001
    }
}
