Add your own genuine WireGuard .conf files in this folder.
Required filenames:
pakistan.conf
usa.conf
uk.conf
germany.conf
japan.conf

Do not use invented endpoints or someone else's private keys.
Each config must come from a WireGuard server you own or are authorized to use.
