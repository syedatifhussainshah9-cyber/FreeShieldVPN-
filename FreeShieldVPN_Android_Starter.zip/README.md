# FreeShield VPN — Android starter project

This is a native Kotlin Android Studio starter app using the official WireGuard Android tunnel library. It has a dark/green interface and attempts a real WireGuard tunnel only when a valid server config is installed.

## Important: server infrastructure is not included
A VPN app cannot provide VPN service by itself. You must operate or rent real WireGuard servers in Pakistan, USA, UK, Germany and Japan. This project deliberately contains **no fake server addresses, private keys, credentials, or simulated connections**.

## Add server configurations
1. Create/lease a WireGuard server in each country you intend to offer.
2. Generate a client profile for this app on each server.
3. Put the matching client configuration files in `app/src/main/assets/wireguard/`:
   - `pakistan.conf`
   - `usa.conf`
   - `uk.conf`
   - `germany.conf`
   - `japan.conf`
4. Keep private keys out of public repositories and never share the APK with embedded personal credentials.
5. Rebuild and test each country independently. A config is not proof that the server is online.

## Free + Premium plan
The sample labels Pakistan and USA as FREE, and UK/Germany/Japan as PREMIUM. These are UI labels only. There is no billing, subscription verification, account system, server provisioning backend, or payment integration in this starter. Add a secure backend and Google Play Billing before selling subscriptions. Do not rely on a client-side premium flag for access control.

## Build on Android
The easiest route is Android Studio on a computer:
1. Open this folder as an existing Gradle project.
2. Use JDK 17 and Android Gradle Plugin 8.7.3.
3. Let Gradle sync and download dependencies.
4. Add your authorized WireGuard configs.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

On an Android phone, a cloud IDE may be needed; Android Studio itself is not officially available as a full native Android development environment.

## Security and production checklist
Before public release, add:
- Server health checks and automatic failover
- Secure server provisioning and key rotation
- A backend that verifies premium entitlements
- Google Play Billing (if distributing through Play)
- Privacy policy, data-retention policy, abuse handling and support
- DNS/IPv6 leak testing, kill-switch behavior testing, reconnect tests
- Independent security review and Play policy review

Never promise “no logs” unless server operations and monitoring genuinely support that claim.
